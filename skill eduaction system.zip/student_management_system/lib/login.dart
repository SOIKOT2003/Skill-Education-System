import 'package:flutter/material.dart';
import 'user.dart'; // Import User class

class LoginPage extends StatelessWidget {
  final List<User> registeredUsers; // Accept registered users as a parameter

  LoginPage({required this.registeredUsers}); // Constructor to receive the registered users

  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  void loginUser(BuildContext context) {
    String email = emailController.text;
    String password = passwordController.text;

    // Check if the email is registered
    User? user = registeredUsers.firstWhere((user) => user.email == email, orElse: () => User(email: '', password: ''));

    if (user.email.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Could not sign-in. Please check your credentials.'),
      ));
      return;
    }

    // Check if the password is correct
    if (user.password != password) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Incorrect password. Please try again.'),
      ));
      return;
    }

    // If successful, navigate to the menu page
    Navigator.pushReplacementNamed(context, '/menu');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/bg1.jpg'), // Path to your image in assets
            fit: BoxFit.cover, // Ensure the image covers the entire screen
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Container(
                width: 300.0, // Set a fixed width for the box
                padding: const EdgeInsets.all(20.0),
                decoration: BoxDecoration(
                  color: Colors.blueGrey.withOpacity(0.7), // Semi-transparent black background
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    TextField(
                      controller: emailController,
                      decoration: InputDecoration(
                        labelText: 'Email',
                        labelStyle: TextStyle(color: Colors.red[700]), // Dark red email label
                        filled: true,
                        fillColor: Colors.black.withOpacity(0.7), // Black background with transparency for email box
                        border: OutlineInputBorder(),
                      ),
                      style: TextStyle(color: Colors.white), // White text inside the text field
                    ),
                    SizedBox(height: 20),
                    TextField(
                      controller: passwordController,
                      decoration: InputDecoration(
                        labelText: 'Password',
                        labelStyle: TextStyle(color: Colors.pink[700]), // Dark pink password label
                        filled: true,
                        fillColor: Colors.black.withOpacity(0.7), // Black background with transparency for password box
                        border: OutlineInputBorder(),
                      ),
                      obscureText: true,
                      style: TextStyle(color: Colors.white), // White text inside the text field
                    ),
                    SizedBox(height: 20),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        ElevatedButton(
                          onPressed: () => loginUser(context),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red, // Red button color for Login
                            padding: EdgeInsets.symmetric(vertical: 16, horizontal: 32),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                          child: Text('Login', style: TextStyle(fontSize: 16, color: Colors.black)), // Black text for Login
                        ),
                        ElevatedButton(
                          onPressed: () {
                            // Navigate to the signup page
                            Navigator.pushNamed(context, '/signUp');
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue[900], // Dark blue button color for Sign Up
                            padding: EdgeInsets.symmetric(vertical: 16, horizontal: 32),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                          child: Text(
                            'Sign Up',
                            style: TextStyle(fontSize: 16, color: Colors.black), // Black text for Sign Up
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
