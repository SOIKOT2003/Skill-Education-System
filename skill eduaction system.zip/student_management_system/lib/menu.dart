import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

class MenuPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Menu'),
      ),
      drawer: Drawer(
        child: Container(
          color: Colors.blue[900], // Deep blue background color for the drawer
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              UserAccountsDrawerHeader(
                accountName: Text('Name', style: TextStyle(color: Colors.white)),
                accountEmail: Text('soikot@gmail.com', style: TextStyle(color: Colors.white)),
                decoration: BoxDecoration(color: Colors.blue[900]),
              ),
              ListTile(
                title: Text('Upcoming Seminars', style: TextStyle(color: Colors.white)),
                onTap: () {
                  Navigator.pushNamed(context, '/upcomingSeminar');
                },
              ),
              ListTile(
                title: Text('Previous Seminars', style: TextStyle(color: Colors.white)),
                onTap: () {
                  Navigator.pushNamed(context, '/previousSeminar');
                },
              ),
              ListTile(
                title: Text('Recorded Classes', style: TextStyle(color: Colors.white)),
                onTap: () {
                  Navigator.pushNamed(context, '/recordedClass');
                },
              ),
              ListTile(
                title: Text('Workshops', style: TextStyle(color: Colors.white)),
                onTap: () {
                  Navigator.pushNamed(context, '/workshop');
                },
              ),
            ],
          ),
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Background image
          Image.asset(
            'assets/bg2.jpg',
            fit: BoxFit.cover,
          ),
          // Overlay to darken the background
          Container(
            color: Colors.black.withOpacity(0.5),
          ),
          // Centered dynamic calendar with login page styling
          Center(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Container(
                  width: 300.0, // Set a fixed width for the calendar container
                  padding: const EdgeInsets.all(20.0),
                  decoration: BoxDecoration(
                    color: Colors.blueGrey.withOpacity(0.7), // Semi-transparent background
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: TableCalendar(
                    focusedDay: DateTime.now(),
                    firstDay: DateTime(2000),
                    lastDay: DateTime(2100),
                    calendarStyle: CalendarStyle(
                      todayDecoration: BoxDecoration(
                        color: Colors.blue[900],
                        shape: BoxShape.circle,
                      ),
                      todayTextStyle: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                      outsideDaysVisible: false, // Hide extra days
                      weekendTextStyle: TextStyle(color: Colors.red),
                    ),
                    headerStyle: HeaderStyle(
                      formatButtonVisible: false,
                      titleCentered: true,
                      titleTextStyle: TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.blue[900],
                        borderRadius: BorderRadius.vertical(top: Radius.circular(10)),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
