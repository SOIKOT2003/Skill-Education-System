import 'package:flutter/foundation.dart'; // For kIsWeb
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:io' show Platform; // For platform checks

class RecordedClassPage extends StatelessWidget {
  // List of videos with URLs and assets as thumbnails
  final List<Map<String, String>> videos = [
    {
      'thumbnail': 'assets/bg4.png', // Asset thumbnail
      'url': 'https://youtu.be/B3MoTP3veBk?list=PLjVLYmrlmjGfGLShoW0vVX_tcyT8u1Y3E', // Video URL
    },
    {
      'thumbnail': 'assets/bg5.jpeg',
      'url': 'https://youtu.be/_qkywk2VeHU?list=PLjVLYmrlmjGfGLShoW0vVX_tcyT8u1Y3E',
    },
    {
      'thumbnail': 'assets/bg6.jpeg',
      'url': 'https://youtu.be/JzzBYI2LhLI?list=PLjVLYmrlmjGfGLShoW0vVX_tcyT8u1Y3E',
    },
    {
      'thumbnail': 'assets/bg7.jpeg',
      'url': 'https://youtu.be/nsdW6s3FqUY?list=PLjVLYmrlmjGfGLShoW0vVX_tcyT8u1Y3E',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Recorded Classes'),
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/bg9.jpeg'), // Replace with your background asset
            fit: BoxFit.cover, // Adjust how the image fits
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: GridView.builder(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, // Number of cards per row
              crossAxisSpacing: 16.0,
              mainAxisSpacing: 16.0,
              childAspectRatio: 16 / 9, // Aspect ratio for video cards
            ),
            itemCount: videos.length,
            itemBuilder: (context, index) {
              final video = videos[index];
              return GestureDetector(
                onTap: () {
                  _openVideo(video['url']!);
                },
                child: Card(
                  elevation: 4.0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10.0),
                    child: Stack(
                      children: [
                        Image.asset(
                          video['thumbnail']!, // Load from assets
                          fit: BoxFit.cover,
                          width: double.infinity,
                          height: double.infinity,
                        ),
                        // Play button overlay
                        const Center(
                          child: Icon(
                            Icons.play_circle_fill,
                            color: Colors.white,
                            size: 50.0,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  void _openVideo(String url) async {
    if (kIsWeb) {
      // Web: Open in a new browser tab
      _openInWeb(url);
    } else if (Platform.isAndroid || Platform.isIOS) {
      // Mobile: Open in in-app web view or external browser
      if (await canLaunchUrl(Uri.parse(url))) {
        await launchUrl(
          Uri.parse(url),
          mode: LaunchMode.inAppWebView,
        );
      } else {
        _showErrorDialog('Could not launch the video.');
      }
    } else {
      // Other platforms: Open in external browser
      if (await canLaunchUrl(Uri.parse(url))) {
        await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      } else {
        _showErrorDialog('Could not launch the video.');
      }
    }
  }

  void _openInWeb(String url) {
    try {
      // Dynamically use html.window for the web
      dynamic html = kIsWeb ? Uri.base.origin : null; // Dummy assignment to suppress analyzer
      html.window.open(url, '_blank');
    } catch (e) {
      _showErrorDialog('Could not open the video in a new tab.');
    }
  }

  void _showErrorDialog(String message) {
    print(message); // Replace with actual dialog if needed
  }
}
