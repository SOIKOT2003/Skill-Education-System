import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: UpcomingSeminarPage(),
  ));
}

class UpcomingSeminarPage extends StatelessWidget {
  final List<Seminar> seminars = [
    Seminar(
      name: 'Leadership for Tomorrow',
      date: 'October 5, 2024',
      time: '10:00 AM - 12:00 PM',
      agenda: 'Develop leadership skills to thrive in the future workplace.',
      speaker: 'Dr. Sarah Connor',
      isPaid: true,
    ),
    Seminar(
      name: 'Effective Communication Strategies',
      date: 'October 8, 2024',
      time: '2:00 PM - 4:00 PM',
      agenda: 'Learn powerful communication techniques for the modern world.',
      speaker: 'John Maxwell',
      isPaid: false,
    ),
    Seminar(
      name: 'Time Management Mastery',
      date: 'October 12, 2024',
      time: '11:00 AM - 1:00 PM',
      agenda: 'Master the art of time management and boost productivity.',
      speaker: 'Lisa Anderson',
      isPaid: true,
    ),
    Seminar(
      name: 'Teamwork & Collaboration',
      date: 'October 15, 2024',
      time: '9:00 AM - 11:00 AM',
      agenda: 'Building strong, cohesive teams for better outcomes.',
      speaker: 'Mark Davis',
      isPaid: false,
    ),
    Seminar(
      name: 'Problem Solving Skills',
      date: 'October 18, 2024',
      time: '3:00 PM - 5:00 PM',
      agenda: 'Develop critical thinking and problem-solving strategies.',
      speaker: 'Anna Thompson',
      isPaid: true,
    ),
    Seminar(
      name: 'Emotional Intelligence in Business',
      date: 'October 20, 2024',
      time: '1:00 PM - 3:00 PM',
      agenda: 'Harness emotional intelligence for better business outcomes.',
      speaker: 'Michael Scott',
      isPaid: true,
    ),
    Seminar(
      name: 'Negotiation Tactics',
      date: 'October 22, 2024',
      time: '2:00 PM - 4:00 PM',
      agenda: 'Effective negotiation skills for win-win solutions.',
      speaker: 'Jessica Parker',
      isPaid: false,
    ),
    Seminar(
      name: 'Public Speaking Masterclass',
      date: 'October 25, 2024',
      time: '10:00 AM - 12:00 PM',
      agenda: 'Master the art of public speaking with confidence.',
      speaker: 'James Hargreaves',
      isPaid: true,
    ),
    Seminar(
      name: 'Creative Thinking & Innovation',
      date: 'October 28, 2024',
      time: '4:00 PM - 6:00 PM',
      agenda: 'Unleash creativity for innovation in the workplace.',
      speaker: 'Nancy Drew',
      isPaid: false,
    ),
    Seminar(
      name: 'Conflict Resolution Skills',
      date: 'October 30, 2024',
      time: '9:00 AM - 11:00 AM',
      agenda: 'Resolve conflicts professionally and peacefully.',
      speaker: 'Peter Stone',
      isPaid: true,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Upcoming Seminars'),
        backgroundColor: Colors.blue[900],
      ),
      body: ListView.builder(
        itemCount: seminars.length,
        itemBuilder: (context, index) {
          final seminar = seminars[index];
          return Card(
            elevation: 5,
            margin: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SeminarDetailsPage(seminar: seminar),
                  ),
                );
              },
              child: Padding(
                padding: const EdgeInsets.all(15.0),
                child: Row(
                  children: [
                    Icon(
                      Icons.event,
                      color: Colors.blue[900],
                      size: 40,
                    ),
                    SizedBox(width: 20),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            seminar.name,
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.blue[900],
                            ),
                          ),
                          SizedBox(height: 5),
                          Text(
                            'Date: ${seminar.date}',
                            style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                          ),
                          SizedBox(height: 5),
                          Text(
                            'Time: ${seminar.time}',
                            style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                          ),
                          SizedBox(height: 10),
                          Row(
                            children: [
                              Icon(
                                Icons.person,
                                color: Colors.blue[900],
                                size: 18,
                              ),
                              SizedBox(width: 5),
                              Text(
                                'Speaker: ${seminar.speaker}',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.grey[700],
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 10),
                          Row(
                            children: [
                              Text(
                                seminar.isPaid ? 'Paid' : 'Free',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: seminar.isPaid ? Colors.green : Colors.red,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class Seminar {
  final String name;
  final String date;
  final String time;
  final String agenda;
  final String speaker;
  final bool isPaid;

  Seminar({
    required this.name,
    required this.date,
    required this.time,
    required this.agenda,
    required this.speaker,
    required this.isPaid,
  });
}

class SeminarDetailsPage extends StatelessWidget {
  final Seminar seminar;

  SeminarDetailsPage({required this.seminar});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(seminar.name),
        backgroundColor: Colors.blue[900],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Date of Seminar: ${seminar.date}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
            Text('Time of Seminar: ${seminar.time}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
            Text('Agenda of Seminar: ${seminar.agenda}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
            Text('Speaker of Seminar: ${seminar.speaker}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 20),
            Row(
              children: [
                Text(
                  'Payment Status: ',
                  style: TextStyle(fontSize: 18),
                ),
                Text(
                  seminar.isPaid ? 'Paid' : 'Non-Paid',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: seminar.isPaid ? Colors.green : Colors.red,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
