import 'package:flutter/material.dart';

class PreviousSeminarPage extends StatelessWidget {
  final List<Seminar> previousSeminars = [
    Seminar(
      name: 'Leadership for Today',
      date: 'September 10, 2024',
      time: '10:00 AM - 12:00 PM',
      agenda: 'Enhancing leadership skills for current challenges.',
      speaker: 'Dr. Emma Watson',
      isPaid: true,
    ),
    Seminar(
      name: 'Effective Negotiation Skills',
      date: 'August 15, 2024',
      time: '2:00 PM - 4:00 PM',
      agenda: 'Learning negotiation techniques for better outcomes.',
      speaker: 'Robert Brown',
      isPaid: false,
    ),
    Seminar(
      name: 'Innovation in Business',
      date: 'July 20, 2024',
      time: '1:00 PM - 3:00 PM',
      agenda: 'Fostering innovation to enhance business growth.',
      speaker: 'Sarah Johnson',
      isPaid: true,
    ),
    Seminar(
      name: 'Advanced Marketing Strategies',
      date: 'June 25, 2024',
      time: '9:00 AM - 11:00 AM',
      agenda: 'Understanding advanced marketing techniques.',
      speaker: 'Michael Smith',
      isPaid: true,
    ),
    Seminar(
      name: 'Emotional Intelligence Workshop',
      date: 'May 30, 2024',
      time: '3:00 PM - 5:00 PM',
      agenda: 'Developing emotional intelligence for better leadership.',
      speaker: 'Jessica Taylor',
      isPaid: false,
    ),
    Seminar(
      name: 'Crisis Management Skills',
      date: 'April 28, 2024',
      time: '10:00 AM - 12:00 PM',
      agenda: 'Preparing for and managing crises effectively.',
      speaker: 'David Wilson',
      isPaid: true,
    ),
    Seminar(
      name: 'Creative Problem Solving',
      date: 'March 15, 2024',
      time: '2:00 PM - 4:00 PM',
      agenda: 'Enhancing problem-solving abilities creatively.',
      speaker: 'Linda Lee',
      isPaid: true,
    ),
    Seminar(
      name: 'Team Dynamics',
      date: 'February 10, 2024',
      time: '11:00 AM - 1:00 PM',
      agenda: 'Understanding team dynamics for better collaboration.',
      speaker: 'Kevin Wright',
      isPaid: false,
    ),
    Seminar(
      name: 'Public Relations Mastery',
      date: 'January 8, 2024',
      time: '1:00 PM - 3:00 PM',
      agenda: 'Mastering public relations for your organization.',
      speaker: 'Emily Davis',
      isPaid: true,
    ),
    Seminar(
      name: 'Digital Marketing Trends',
      date: 'December 5, 2023',
      time: '9:00 AM - 11:00 AM',
      agenda: 'Exploring the latest trends in digital marketing.',
      speaker: 'Matthew Jones',
      isPaid: true,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Previous Seminars'),
        backgroundColor: Colors.blue[900],
      ),
      body: ListView.builder(
        itemCount: previousSeminars.length,
        itemBuilder: (context, index) {
          final seminar = previousSeminars[index];
          return Card(
            elevation: 5,
            margin: EdgeInsets.symmetric(vertical: 10, horizontal: 15),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => SeminarDetailsPage(seminar: seminar),
                  ),
                );
              },
              child: Padding(
                padding: const EdgeInsets.all(15.0),
                child: Row(
                  children: [
                    Icon(
                      Icons.event,
                      color: Colors.blue[900],
                      size: 40,
                    ),
                    SizedBox(width: 20),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            seminar.name,
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.blue[900],
                            ),
                          ),
                          SizedBox(height: 5),
                          Text(
                            'Date: ${seminar.date}',
                            style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                          ),
                          SizedBox(height: 5),
                          Text(
                            'Time: ${seminar.time}',
                            style: TextStyle(fontSize: 14, color: Colors.grey[600]),
                          ),
                          SizedBox(height: 10),
                          Row(
                            children: [
                              Icon(
                                Icons.person,
                                color: Colors.blue[900],
                                size: 18,
                              ),
                              SizedBox(width: 5),
                              Text(
                                'Speaker: ${seminar.speaker}',
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.grey[700],
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 10),
                          Row(
                            children: [
                              Text(
                                seminar.isPaid ? 'Paid' : 'Free',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: seminar.isPaid ? Colors.green : Colors.red,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class Seminar {
  final String name;
  final String date;
  final String time;
  final String agenda;
  final String speaker;
  final bool isPaid;

  Seminar({
    required this.name,
    required this.date,
    required this.time,
    required this.agenda,
    required this.speaker,
    required this.isPaid,
  });
}

class SeminarDetailsPage extends StatelessWidget {
  final Seminar seminar;

  SeminarDetailsPage({required this.seminar});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(seminar.name),
        backgroundColor: Colors.blue[900],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Date of Seminar: ${seminar.date}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
            Text('Time of Seminar: ${seminar.time}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
            Text('Agenda of Seminar: ${seminar.agenda}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 10),
            Text('Speaker of Seminar: ${seminar.speaker}', style: TextStyle(fontSize: 18)),
            SizedBox(height: 20),
            Row(
              children: [
                Text(
                  'Payment Status: ',
                  style: TextStyle(fontSize: 18),
                ),
                Text(
                  seminar.isPaid ? 'Paid' : 'Non-Paid',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: seminar.isPaid ? Colors.green : Colors.red,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
