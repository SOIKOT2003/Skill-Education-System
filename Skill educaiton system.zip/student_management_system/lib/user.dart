// user.dart
class User {
  final String email;
  final String password;

  User({required this.email, required this.password});

// Optional: You can add methods or additional properties here if needed in the future
}
