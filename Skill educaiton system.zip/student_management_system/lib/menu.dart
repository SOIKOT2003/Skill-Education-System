import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

class MenuPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Menu'),
        backgroundColor: Colors.blue[900], // Ensure consistent AppBar color
      ),
      drawer: Drawer(
        child: Container(
          color: Colors.blue[900], // Deep blue background color for the drawer
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              UserAccountsDrawerHeader(
                accountName: const Text(
                  'Name',
                  style: TextStyle(color: Colors.white),
                ),
                accountEmail: const Text(
                  'soikot@gmail.com',
                  style: TextStyle(color: Colors.white),
                ),
                decoration: BoxDecoration(color: Colors.blue[900]),
              ),
              ListTile(
                leading: const Icon(Icons.event, color: Colors.white),
                title: const Text(
                  'Upcoming Seminars',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.pushNamed(context, '/upcomingSeminar');
                },
              ),
              ListTile(
                leading: const Icon(Icons.history, color: Colors.white),
                title: const Text(
                  'Previous Seminars',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.pushNamed(context, '/previousSeminar');
                },
              ),
              ListTile(
                leading: const Icon(Icons.video_library, color: Colors.white),
                title: const Text(
                  'Recorded Classes',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.pushNamed(context, '/recordedClass');
                },
              ),
              ListTile(
                leading: const Icon(Icons.work, color: Colors.white),
                title: const Text(
                  'Workshops',
                  style: TextStyle(color: Colors.white),
                ),
                onTap: () {
                  Navigator.pushNamed(context, '/workshop');
                },
              ),
            ],
          ),
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          // Background image
          Image.asset(
            'assets/bg2.jpg',
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) {
              // Display a placeholder in case the asset is missing
              return Container(
                color: Colors.grey,
                child: const Center(
                  child: Text(
                    'Background Image Missing',
                    style: TextStyle(color: Colors.white),
                  ),
                ),
              );
            },
          ),
          // Overlay to darken the background
          Container(
            color: Colors.black.withOpacity(0.5),
          ),
          // Centered dynamic calendar with login page styling
          Center(
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Container(
                  width: 300.0, // Set a fixed width for the calendar container
                  padding: const EdgeInsets.all(20.0),
                  decoration: BoxDecoration(
                    color: Colors.blueGrey.withOpacity(0.7), // Semi-transparent background
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: TableCalendar(
                    focusedDay: DateTime.now(),
                    firstDay: DateTime(2000),
                    lastDay: DateTime(2100),
                    calendarStyle: CalendarStyle(
                      todayDecoration: BoxDecoration(
                        color: Colors.blue[900],
                        shape: BoxShape.circle,
                      ),
                      todayTextStyle: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                      outsideDaysVisible: false, // Hide extra days
                      weekendTextStyle: const TextStyle(color: Colors.red),
                      defaultTextStyle: const TextStyle(color: Colors.black),
                    ),
                    headerStyle: HeaderStyle(
                      formatButtonVisible: false,
                      titleCentered: true,
                      titleTextStyle: const TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.blue[900],
                        borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(10),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
