import 'package:flutter/material.dart';
import 'login.dart';
import 'signUp.dart';
import 'upcomingSeminar.dart';
import 'previousSeminar.dart';
import 'recordedClass.dart';
import 'workshop.dart';
import 'menu.dart';
import 'user.dart'; // Import User class

void main() {
  runApp(StudentManagementSystem());
}

class StudentManagementSystem extends StatelessWidget {
  final List<User> registeredUsers = []; // Initialize the registered users list

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Student Management System',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/login',
      routes: {
        '/login': (context) => LoginPage(registeredUsers: registeredUsers),
        '/signUp': (context) => SignUpPage(registeredUsers: registeredUsers), // Pass the registered users
        '/menu1': (context) => MenuPage(),
        '/upcomingSeminar': (context) => UpcomingSeminarPage(),
        '/previousSeminar': (context) => PreviousSeminarPage(),
        '/recordedClass': (context) => RecordedClassPage(),
        '/workshop': (context) => WorkshopPage(),
        '/menu' :(context) => MenuPage()
      },
    );
  }
}
