import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class WorkshopPage extends StatelessWidget {
  final String backgroundImage = 'assets/bg8.jpeg'; // Background image

  final List<Map<String, String>> workshops = [
    {
      "title": "Wadhwani Foundation",
      "description": "Empowering entrepreneurs and driving skill development.",
      "url": "https://wadhwanifoundation.org/",
    },
    {
      "title": "SkillSprout Foundation",
      "description": "Enhancing skills for future professionals.",
      "url": "https://skillsproutfoundation.org/", // Placeholder URL
    },
    {
      "title": "EmpowerU Foundation",
      "description": "Fostering education and empowerment initiatives.",
      "url": "https://empowerufoundation.org/", // Placeholder URL
    },
    {
      "title": "CodeAcademy",
      "description": "Learn coding skills for a modern career.",
      "url": "https://www.codecademy.com/",
    },
    {
      "title": "Coursera",
      "description": "Online courses from top universities.",
      "url": "https://www.coursera.org/",
    },
    {
      "title": "Udemy",
      "description": "Affordable courses on various skills.",
      "url": "https://www.udemy.com/",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Workshops'),
        backgroundColor: Colors.blueAccent,
      ),
      drawer: Drawer(
        child: Container(
          color: Colors.red, // Drawer background color
          child: ListView.builder(
            itemCount: workshops.length,
            itemBuilder: (context, index) {
              final workshop = workshops[index];
              return ListTile(
                title: Text(
                  workshop['title']!,
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
                subtitle: Text(
                  workshop['description']!,
                  style: TextStyle(color: Colors.white70),
                ),
                trailing: Icon(Icons.arrow_forward_ios, color: Colors.white),
                onTap: () {
                  Navigator.pop(context); // Close the drawer
                  _launchURL(workshop['url']!);
                },
              );
            },
          ),
        ),
      ),
      body: Stack(
        children: [
          // Background Image
          Positioned.fill(
            child: Image.asset(
              backgroundImage,
              fit: BoxFit.cover,
            ),
          ),
          // Content Layer
          ListView.separated(
            itemCount: workshops.length,
            separatorBuilder: (context, index) => Divider(color: Colors.white70),
            itemBuilder: (context, index) {
              final workshop = workshops[index];
              return Card(
                color: Colors.white.withOpacity(0.8),
                elevation: 2.0,
                margin: EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.blueAccent,
                    child: Icon(
                      Icons.work,
                      color: Colors.white,
                    ),
                  ),
                  title: Text(
                    workshop['title']!,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  subtitle: Text(
                    workshop['description']!,
                    style: TextStyle(color: Colors.grey[800]),
                  ),
                  trailing: Icon(Icons.arrow_forward_ios, color: Colors.blueAccent),
                  onTap: () => _launchURL(workshop['url']!),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  void _launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }
}
