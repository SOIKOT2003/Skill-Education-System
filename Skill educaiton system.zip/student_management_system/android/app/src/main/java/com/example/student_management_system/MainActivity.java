package com.example.student_management_system;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
